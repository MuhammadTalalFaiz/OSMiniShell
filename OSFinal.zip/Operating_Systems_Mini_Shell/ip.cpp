#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void printIP() {
    int socket_fd = socket(AF_INET, SOCK_DGRAM, 0); // Use SOCK_DGRAM instead of SOCK_STREAM

    if (socket_fd < 0) {
        perror("socket");
        return;
    }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK); // Use INADDR_LOOPBACK for loopback address

    if (bind(socket_fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(socket_fd);
        return;
    }

    struct sockaddr_in local_addr;
    socklen_t addr_len = sizeof(local_addr);
    if (getsockname(socket_fd, (struct sockaddr*)&local_addr, &addr_len) < 0) {
        perror("getsockname");
        close(socket_fd);
        return;
    }

    char ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(local_addr.sin_addr), ip, INET_ADDRSTRLEN);
    printf("Local IP Address: %s\n", ip);

    close(socket_fd);
}
