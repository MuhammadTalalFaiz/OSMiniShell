#include "history.h"
#include <string.h>
#include <stdio.h>

void addToHistory(char *command) {

// Store command in history array
strcpy(commandHistory[historyIndex], command); //first argument is destination, second is source

// Increment history index
historyIndex++;

// Wrap around array
if (historyIndex == HISTORY_SIZE) {
historyIndex = 0;
}
}

void printHistory() {

// Start from last command
int i = historyIndex - 1;

while(i != historyIndex&&i>=0) {

printf("%s\n", commandHistory[i]);

i--;
}
}

void upArrow() {
if (historyPosition > 0) {
    historyPosition--;
  
// Get previous command 
char *prevCommand = commandHistory[historyPosition];
}
}
void downArrow() {

// Check if next command exists
if (historyPosition < historyIndex - 1) {
historyPosition++;
// Get next command    
char *nextCommand = commandHistory[historyPosition];   
}
}