#include "proclist.h"
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void getProcessList() {
    DIR* procDir = opendir("/proc");
    if (procDir == NULL) {
        perror("opendir");
        return;
    }

    struct dirent* dirEntry;
    while ((dirEntry = readdir(procDir)) != NULL) {
        if (dirEntry->d_type == DT_DIR) {
            // Check if the directory entry is a process ID (numeric)
            int pid = atoi(dirEntry->d_name);
            if (pid > 0) {
                char* name = getProcessName(pid);
                if (name != NULL) {
                    printf("PID: %d Process name: %s\n", pid, name);
                    free(name);
                }
            }
        }
    }

    closedir(procDir);
}

char* getProcessName(int pid) {
    char path[256];
    sprintf(path, "/proc/%d/comm", pid);

    FILE* file = fopen(path, "r");
    if (file == NULL) {
        perror("fopen");
        return NULL;
    }

    char* procname = (char*)malloc(256);
    if (procname == NULL) {
        perror("malloc");
        fclose(file);
        return NULL;
    }

    if (fgets(procname, 256, file) == NULL) {
        perror("fgets");
        fclose(file);
        free(procname);
        return NULL;
    }

    size_t nameLength = strlen(procname);
    if (nameLength > 0 && procname[nameLength - 1] == '\n') {
        procname[nameLength - 1] = '\0'; // Remove newline character
    }

    fclose(file);
    return procname;
}
