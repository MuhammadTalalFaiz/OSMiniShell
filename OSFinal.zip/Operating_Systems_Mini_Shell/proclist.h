#ifndef PROCLIST_H
#define PROCLIST_H

void getProcessList();
char* getProcessName(int pid);

#endif