#ifndef IP_H
#define IP_H

void printIP();

#endif