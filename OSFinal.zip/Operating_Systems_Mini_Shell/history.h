#ifndef HISTORY_H
#define HISTORY_H

#define HISTORY_SIZE 100

extern char commandHistory[HISTORY_SIZE][250];
extern int historyIndex;
extern int historyPosition;

void addToHistory(char *command);
void printHistory();
void upArrow();
void downArrow();

#endif